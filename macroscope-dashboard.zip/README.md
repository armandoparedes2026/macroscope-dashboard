# MacroScope — Dashboard macroeconómico

Dashboard ejecutivo interactivo para seguimiento de indicadores macroeconómicos, comparación internacional y simulación financiera exploratoria.

## Abrir el proyecto

Abre [`index.html`](index.html) en un navegador moderno. No requiere un proceso de compilación ni servidor de aplicaciones. Para publicar el sitio más adelante, `index.html` está preparado como punto de entrada para alojamiento estático.

## Funciones

- Panorama ejecutivo con indicadores del Banco Mundial (WDI).
- Comparación entre países y América Latina y el Caribe.
- Gráficas de series históricas y comparaciones internacionales.
- Carrusel de lecturas gerenciales y visualización adaptable.
- Referencias cambiarias con Open ER API.
- Simulación ilustrativa de sensibilidad financiera (ingresos, costos y EBITDA).
- Tabla histórica con exportación CSV e inspector de las consultas API.
- Tema claro/oscuro.

## Fuentes y limitaciones

- Banco Mundial (World Development Indicators): https://api.worldbank.org/v2/
- Tipos de cambio indicativos: https://open.er-api.com/v6/latest/USD

Los indicadores macroeconómicos son de periodicidad **anual**, no cifras intradía. Si fallan las APIs, el dashboard puede mostrar **datos históricos locales de respaldo**; verifica el estado de conexión y el año de cada dato antes de usarlo.

Los cálculos del simulador son **supuestos orientativos**, no pronósticos econométricos validados ni asesoramiento financiero. Los tipos de cambio de referencia no equivalen a cotizaciones bancarias de compra/venta.

## Tecnología

HTML, CSS y JavaScript integrados en `index.html`. El documento solicita Chart.js y tipografías desde CDN cuando hay conexión; incluye una representación alternativa de gráficos si Chart.js no carga.

## Estructura

```text
macroscope-dashboard/
├── index.html
├── README.md
└── .gitignore
```
